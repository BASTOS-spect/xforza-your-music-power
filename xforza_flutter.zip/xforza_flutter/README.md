# XFORZA Flutter

Versão mobile da plataforma de streaming XFORZA — convertida do React/TanStack Router para Flutter + Provider.

## Stack

| React (web) | Flutter (mobile) |
|---|---|
| TanStack Router | go_router |
| React Context (PlayerProvider) | Provider + ChangeNotifier |
| iTunes API fetch | http package |
| localStorage | shared_preferences |
| Howler / HTML Audio | just_audio |
| Tailwind CSS | ThemeData + GoogleFonts |
| React Query cache | FutureBuilder (stateful widget cache) |

## Estrutura

```
lib/
├── main.dart                  # Entry point
├── router.dart                # Rotas (go_router)
├── models/
│   └── track.dart             # Modelo Track (= tipo Track do TS)
├── services/
│   └── music_api.dart         # iTunes Search API wrapper
├── providers/
│   └── player_provider.dart   # Estado global do player (= PlayerContext)
├── theme/
│   └── app_theme.dart         # Paleta XFORZA (dark, vermelho #E50914)
├── screens/
│   ├── home_screen.dart       # Página inicial (= _layout.index.tsx)
│   ├── search_screen.dart     # Busca (= _layout.buscar.tsx)
│   ├── library_screen.dart    # Biblioteca/Favoritos (= _layout.biblioteca.tsx)
│   └── plans_screen.dart      # Planos (= _layout.planos.tsx)
└── widgets/
    ├── app_shell.dart          # Bottom nav + mini player (= AppLayout + MobileNav)
    └── music_widgets.dart      # TrackCard, TrackRow, CardSkeleton, MiniPlayerBar
```

## Setup

### Pré-requisitos
- Flutter SDK ≥ 3.3.0
- Dart ≥ 3.3.0

### Instalar dependências

```bash
flutter pub get
```

### Rodar no emulador / dispositivo

```bash
flutter run
```

### Build de produção

```bash
# Android
flutter build apk --release

# iOS
flutter build ipa --release
```

## Funcionalidades

- **Início** — Banner hero, categorias em grid, playlists por objetivo, gêneros
- **Buscar** — Campo de pesquisa + sugestões rápidas → lista de faixas
- **Biblioteca** — Favoritos persistidos via SharedPreferences
- **Planos** — Cards Livre / Premium / Ultra com destaque visual
- **Mini Player** — Barra inferior: capa, título, play/pause, anterior/próxima, progresso
- **Favoritar** — Coração em qualquer faixa → salvo localmente

## Notas

- A API iTunes retorna previews de 30 segundos gratuitamente (sem key).
- O campo `preview` URL vem diretamente da Apple — `just_audio` faz streaming direto.
- Favoritos são salvos em `SharedPreferences` com a chave `xforza:favs:v1` (mesma do web).
- Para adicionar autenticação Supabase, inclua o pacote `supabase_flutter` e configure 
  as variáveis `SUPABASE_URL` e `SUPABASE_ANON_KEY` via `--dart-define` no build.
