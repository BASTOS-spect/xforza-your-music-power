class Track {
  final String id;
  final String title;
  final String artist;
  final String album;
  final String cover;
  final String preview;
  final int duration; // seconds
  final String genre;

  const Track({
    required this.id,
    required this.title,
    required this.artist,
    required this.album,
    required this.cover,
    required this.preview,
    required this.duration,
    required this.genre,
  });

  factory Track.fromJson(Map<String, dynamic> r) {
    final artworkUrl = (r['artworkUrl100'] as String? ?? '')
        .replaceAll('100x100bb', '600x600bb');
    return Track(
      id: r['trackId'].toString(),
      title: r['trackName'] as String? ?? '',
      artist: r['artistName'] as String? ?? '',
      album: r['collectionName'] as String? ?? '',
      cover: artworkUrl,
      preview: r['previewUrl'] as String? ?? '',
      duration: (((r['trackTimeMillis'] as num?) ?? 0) / 1000).round(),
      genre: r['primaryGenreName'] as String? ?? '',
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'artist': artist,
        'album': album,
        'cover': cover,
        'preview': preview,
        'duration': duration,
        'genre': genre,
      };

  factory Track.fromStoredJson(Map<String, dynamic> json) => Track(
        id: json['id'] as String,
        title: json['title'] as String,
        artist: json['artist'] as String,
        album: json['album'] as String,
        cover: json['cover'] as String,
        preview: json['preview'] as String,
        duration: json['duration'] as int,
        genre: json['genre'] as String,
      );
}
