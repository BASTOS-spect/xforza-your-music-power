import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shimmer/shimmer.dart';
import '../models/track.dart';
import '../providers/player_provider.dart';
import '../theme/app_theme.dart';

// ── Card Skeleton ────────────────────────────────────────────────────────────

class CardSkeleton extends StatelessWidget {
  const CardSkeleton({super.key});

  @override
  Widget build(BuildContext context) {
    return Shimmer.fromColors(
      baseColor: kSurfaceElevated,
      highlightColor: const Color(0xFF2A2A2A),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          AspectRatio(
            aspectRatio: 1,
            child: Container(
              decoration: BoxDecoration(
                color: kSurfaceElevated,
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ),
          const SizedBox(height: 10),
          Container(
            height: 12,
            width: double.infinity,
            decoration: BoxDecoration(
              color: kSurfaceElevated,
              borderRadius: BorderRadius.circular(6),
            ),
          ),
          const SizedBox(height: 6),
          Container(
            height: 10,
            width: 80,
            decoration: BoxDecoration(
              color: kSurfaceElevated,
              borderRadius: BorderRadius.circular(5),
            ),
          ),
        ],
      ),
    );
  }
}

// ── Track Card (grid view) ───────────────────────────────────────────────────

class TrackCard extends StatelessWidget {
  final Track track;
  final List<Track> queue;

  const TrackCard({super.key, required this.track, required this.queue});

  @override
  Widget build(BuildContext context) {
    final player = context.watch<PlayerProvider>();
    final isCurrent = player.current?.id == track.id;
    final isFav = player.isFavorite(track.id);

    return GestureDetector(
      onTap: () => player.play(track, newQueue: queue),
      child: Container(
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [kSurfaceElevated, kSurface],
          ),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Cover
            Stack(
              children: [
                AspectRatio(
                  aspectRatio: 1,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: CachedNetworkImage(
                      imageUrl: track.cover,
                      fit: BoxFit.cover,
                      placeholder: (_, __) => Container(color: kSurfaceElevated),
                      errorWidget: (_, __, ___) => Container(
                        color: kSurfaceElevated,
                        child: const Icon(Icons.music_note, color: kMuted),
                      ),
                    ),
                  ),
                ),
                // Playing indicator
                if (isCurrent && player.playing)
                  Positioned.fill(
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: Container(
                        color: Colors.black54,
                        child: const Center(
                          child: Icon(Icons.graphic_eq, color: kPrimary, size: 28),
                        ),
                      ),
                    ),
                  ),
                // Play button overlay
                Positioned(
                  bottom: 8,
                  right: 8,
                  child: Container(
                    width: 38,
                    height: 38,
                    decoration: BoxDecoration(
                      gradient: gradientPrimary,
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: kPrimary.withAlpha(100),
                          blurRadius: 12,
                          spreadRadius: 2,
                        ),
                      ],
                    ),
                    child: const Icon(Icons.play_arrow, color: kForeground, size: 20),
                  ),
                ),
              ],
            ),
            // Info
            Padding(
              padding: const EdgeInsets.fromLTRB(8, 8, 8, 4),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          track.title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                            color: isCurrent ? kPrimary : kForeground,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          track.artist,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontSize: 11, color: kMuted),
                        ),
                      ],
                    ),
                  ),
                  GestureDetector(
                    onTap: () => player.toggleFavorite(track),
                    child: Icon(
                      isFav ? Icons.favorite : Icons.favorite_border,
                      size: 16,
                      color: isFav ? kPrimary : kMuted,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Track Row (list view) ────────────────────────────────────────────────────

class TrackRow extends StatelessWidget {
  final Track track;
  final List<Track> queue;
  final int index;

  const TrackRow({
    super.key,
    required this.track,
    required this.queue,
    required this.index,
  });

  @override
  Widget build(BuildContext context) {
    final player = context.watch<PlayerProvider>();
    final isCurrent = player.current?.id == track.id;
    final isFav = player.isFavorite(track.id);

    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      tileColor: Colors.transparent,
      onTap: () => player.play(track, newQueue: queue),
      leading: SizedBox(
        width: 44,
        child: Stack(
          alignment: Alignment.center,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(6),
              child: CachedNetworkImage(
                imageUrl: track.cover,
                width: 44,
                height: 44,
                fit: BoxFit.cover,
                placeholder: (_, __) => Container(width: 44, height: 44, color: kSurfaceElevated),
                errorWidget: (_, __, ___) =>
                    Container(width: 44, height: 44, color: kSurfaceElevated),
              ),
            ),
            if (isCurrent && player.playing)
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: Colors.black54,
                  borderRadius: BorderRadius.circular(6),
                ),
                child: const Icon(Icons.graphic_eq, color: kPrimary, size: 18),
              ),
          ],
        ),
      ),
      title: Text(
        track.title,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(
          fontSize: 13,
          fontWeight: FontWeight.w600,
          color: isCurrent ? kPrimary : kForeground,
        ),
      ),
      subtitle: Text(
        '${track.artist} · ${track.album}',
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: const TextStyle(fontSize: 11, color: kMuted),
      ),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          GestureDetector(
            onTap: () => player.toggleFavorite(track),
            child: Icon(
              isFav ? Icons.favorite : Icons.favorite_border,
              size: 18,
              color: isFav ? kPrimary : kMuted,
            ),
          ),
          const SizedBox(width: 10),
          Text(
            formatTime(track.duration),
            style: const TextStyle(fontSize: 11, color: kMuted),
          ),
        ],
      ),
    );
  }
}

// ── Mini Player Bar ──────────────────────────────────────────────────────────

class MiniPlayerBar extends StatelessWidget {
  const MiniPlayerBar({super.key});

  @override
  Widget build(BuildContext context) {
    final player = context.watch<PlayerProvider>();
    final track = player.current;

    return Container(
      decoration: const BoxDecoration(
        color: kSurface,
        border: Border(top: BorderSide(color: kBorder)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Progress line
          LinearProgressIndicator(
            value: player.progress,
            backgroundColor: kBorder,
            valueColor: const AlwaysStoppedAnimation<Color>(kPrimary),
            minHeight: 2,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            child: Row(
              children: [
                // Cover
                ClipRRect(
                  borderRadius: BorderRadius.circular(6),
                  child: track?.cover.isNotEmpty == true
                      ? CachedNetworkImage(
                          imageUrl: track!.cover,
                          width: 42,
                          height: 42,
                          fit: BoxFit.cover,
                        )
                      : Container(
                          width: 42,
                          height: 42,
                          decoration: BoxDecoration(
                            gradient: gradientPrimary,
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: const Icon(Icons.music_note, color: kForeground, size: 20),
                        ),
                ),
                const SizedBox(width: 12),
                // Title + artist
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        track?.title ?? 'Pronto para tocar',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                          color: kForeground,
                        ),
                      ),
                      Text(
                        track?.artist ?? 'Escolha uma música',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 11, color: kMuted),
                      ),
                    ],
                  ),
                ),
                // Favorite
                if (track != null)
                  IconButton(
                    onPressed: () => player.toggleFavorite(track),
                    icon: Icon(
                      player.isFavorite(track.id) ? Icons.favorite : Icons.favorite_border,
                      color: player.isFavorite(track.id) ? kPrimary : kMuted,
                      size: 20,
                    ),
                  ),
                // Prev
                IconButton(
                  onPressed: track != null ? player.skipPrev : null,
                  icon: const Icon(Icons.skip_previous, color: kForeground),
                ),
                // Play/Pause
                GestureDetector(
                  onTap: track != null ? player.toggle : null,
                  child: Container(
                    width: 38,
                    height: 38,
                    decoration: BoxDecoration(
                      color: track != null ? kForeground : kMuted,
                      shape: BoxShape.circle,
                    ),
                    child: Icon(
                      player.playing ? Icons.pause : Icons.play_arrow,
                      color: kBackground,
                      size: 20,
                    ),
                  ),
                ),
                // Next
                IconButton(
                  onPressed: track != null ? player.skipNext : null,
                  icon: const Icon(Icons.skip_next, color: kForeground),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
