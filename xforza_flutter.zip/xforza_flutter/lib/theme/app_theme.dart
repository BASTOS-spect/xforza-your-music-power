import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

// XFORZA palette — mirrors the CSS variables in styles.css
const kBackground = Color(0xFF0A0A0A);
const kSurface = Color(0xFF151515);
const kSurfaceElevated = Color(0xFF1E1E1E);
const kPrimary = Color(0xFFE50914);
const kPrimaryDark = Color(0xFFB30000);
const kForeground = Color(0xFFFFFFFF);
const kMuted = Color(0xFFC7C7C7);
const kBorder = Color(0x14FFFFFF); // white 8%

ThemeData xforzaTheme() {
  final base = ThemeData.dark(useMaterial3: true);
  return base.copyWith(
    scaffoldBackgroundColor: kBackground,
    colorScheme: const ColorScheme.dark(
      surface: kSurface,
      primary: kPrimary,
      onPrimary: kForeground,
      secondary: kPrimaryDark,
      onSecondary: kForeground,
      onSurface: kForeground,
      outline: kBorder,
    ),
    textTheme: GoogleFonts.interTextTheme(base.textTheme).apply(
      bodyColor: kForeground,
      displayColor: kForeground,
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: kSurface,
      foregroundColor: kForeground,
      elevation: 0,
      surfaceTintColor: Colors.transparent,
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: kSurface,
      indicatorColor: kPrimary.withAlpha(40),
      labelTextStyle: WidgetStateProperty.resolveWith((states) {
        if (states.contains(WidgetState.selected)) {
          return GoogleFonts.montserrat(
            fontSize: 10,
            fontWeight: FontWeight.w700,
            color: kPrimary,
          );
        }
        return GoogleFonts.montserrat(
          fontSize: 10,
          fontWeight: FontWeight.w600,
          color: kMuted,
        );
      }),
      iconTheme: WidgetStateProperty.resolveWith((states) {
        return IconThemeData(
          color: states.contains(WidgetState.selected) ? kPrimary : kMuted,
          size: 22,
        );
      }),
    ),
    sliderTheme: const SliderThemeData(
      activeTrackColor: kPrimary,
      inactiveTrackColor: kBorder,
      thumbColor: kForeground,
      overlayColor: Color(0x1AE50914),
      trackHeight: 3,
      thumbShape: RoundSliderThumbShape(enabledThumbRadius: 6),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: kSurface,
      hintStyle: const TextStyle(color: kMuted),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(32),
        borderSide: const BorderSide(color: kBorder),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(32),
        borderSide: const BorderSide(color: kBorder),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(32),
        borderSide: const BorderSide(color: kPrimary, width: 1.5),
      ),
      contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
    ),
    dividerColor: kBorder,
  );
}

// Helpers
LinearGradient get gradientPrimary => const LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: [kPrimary, kPrimaryDark],
    );
