import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:just_audio/just_audio.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/track.dart';

const _favKey = 'xforza:favs:v1';

String formatTime(int seconds) {
  if (seconds <= 0) return '0:00';
  final m = seconds ~/ 60;
  final s = (seconds % 60).toString().padLeft(2, '0');
  return '$m:$s';
}

class PlayerProvider extends ChangeNotifier {
  final AudioPlayer _audio = AudioPlayer();

  Track? current;
  List<Track> queue = [];
  bool playing = false;
  Duration currentTime = Duration.zero;
  Duration duration = Duration.zero;
  double volume = 0.7;

  // Favorites
  final Set<String> _favoriteIds = {};
  final List<Track> favoriteTracks = [];

  double get progress =>
      duration.inMilliseconds > 0
          ? currentTime.inMilliseconds / duration.inMilliseconds
          : 0.0;

  PlayerProvider() {
    _init();
  }

  Future<void> _init() async {
    await _audio.setVolume(volume);

    _audio.positionStream.listen((pos) {
      currentTime = pos;
      notifyListeners();
    });

    _audio.durationStream.listen((dur) {
      duration = dur ?? Duration.zero;
      notifyListeners();
    });

    _audio.playingStream.listen((p) {
      playing = p;
      notifyListeners();
    });

    _audio.playerStateStream.listen((state) {
      if (state.processingState == ProcessingState.completed) {
        skipNext();
      }
    });

    await _loadFavorites();
  }

  Future<void> _loadFavorites() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_favKey);
      if (raw != null) {
        final list = (jsonDecode(raw) as List<dynamic>)
            .cast<Map<String, dynamic>>()
            .map(Track.fromStoredJson)
            .toList();
        favoriteTracks.clear();
        favoriteTracks.addAll(list);
        _favoriteIds
          ..clear()
          ..addAll(list.map((t) => t.id));
        notifyListeners();
      }
    } catch (_) {}
  }

  Future<void> _saveFavorites() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final encoded =
          jsonEncode(favoriteTracks.map((t) => t.toJson()).toList());
      await prefs.setString(_favKey, encoded);
    } catch (_) {}
  }

  Future<void> play(Track track, {List<Track>? newQueue}) async {
    if (track.preview.isEmpty) return;
    current = track;
    if (newQueue != null) queue = newQueue;
    try {
      await _audio.setUrl(track.preview);
      await _audio.play();
    } catch (_) {
      playing = false;
    }
    notifyListeners();
  }

  Future<void> toggle() async {
    if (current == null) return;
    if (playing) {
      await _audio.pause();
    } else {
      await _audio.play();
    }
  }

  void skipNext() {
    if (current == null || queue.isEmpty) return;
    final i = queue.indexWhere((t) => t.id == current!.id);
    final next = queue[(i + 1) % queue.length];
    play(next, newQueue: queue);
  }

  void skipPrev() {
    if (current == null || queue.isEmpty) return;
    final i = queue.indexWhere((t) => t.id == current!.id);
    final prev = queue[(i - 1 + queue.length) % queue.length];
    play(prev, newQueue: queue);
  }

  Future<void> seek(double ratio) async {
    if (duration == Duration.zero) return;
    final ms = (ratio * duration.inMilliseconds).clamp(0, duration.inMilliseconds).toInt();
    await _audio.seek(Duration(milliseconds: ms));
  }

  Future<void> setVolume(double v) async {
    volume = v.clamp(0.0, 1.0);
    await _audio.setVolume(volume);
    notifyListeners();
  }

  void toggleFavorite(Track track) {
    if (_favoriteIds.contains(track.id)) {
      _favoriteIds.remove(track.id);
      favoriteTracks.removeWhere((t) => t.id == track.id);
    } else {
      _favoriteIds.add(track.id);
      favoriteTracks.insert(0, track);
    }
    notifyListeners();
    _saveFavorites();
  }

  bool isFavorite(String id) => _favoriteIds.contains(id);

  @override
  void dispose() {
    _audio.dispose();
    super.dispose();
  }
}
