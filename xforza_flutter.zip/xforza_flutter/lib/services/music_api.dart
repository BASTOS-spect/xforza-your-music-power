import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/track.dart';

const _base = 'https://itunes.apple.com/search';

const categoryQueries = {
  'trending': 'top hits 2025',
  'novidades': 'lançamentos pop 2025',
  'treino': 'workout motivation',
  'foco': 'lofi study beats',
  'relaxar': 'chill acoustic',
  'viagem': 'road trip summer',
  'motivacao': 'hits brasil',
  'pop': 'pop hits',
  'rock': 'rock classics',
  'hiphop': 'hip hop brasil',
  'eletronica': 'electronic dance',
  'lofi': 'lofi hip hop',
};

class MusicApi {
  static Future<List<Track>> searchTracks(String term, {int limit = 24}) async {
    if (term.trim().isEmpty) return [];
    final uri = Uri.parse(
        '$_base?term=${Uri.encodeComponent(term)}&entity=song&limit=$limit&country=BR&lang=pt_br');
    final res = await http.get(uri);
    if (res.statusCode != 200) throw Exception('Falha na busca');
    final json = jsonDecode(res.body) as Map<String, dynamic>;
    final results = (json['results'] as List<dynamic>? ?? [])
        .cast<Map<String, dynamic>>()
        .where((r) => r['previewUrl'] != null && r['artworkUrl100'] != null)
        .map(Track.fromJson)
        .toList();
    return results;
  }

  static Future<List<Track>> getCategory(String key, {int limit = 12}) {
    final query = categoryQueries[key] ?? key;
    return searchTracks(query, limit: limit);
  }
}
