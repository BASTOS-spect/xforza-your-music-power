import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../models/track.dart';
import '../services/music_api.dart';
import '../theme/app_theme.dart';
import '../widgets/music_widgets.dart';

const _suggestions = [
  'Anitta',
  'The Weeknd',
  'Henrique e Juliano',
  'Lo-Fi',
  'Workout',
  'Marília Mendonça',
  'Bad Bunny',
  'Coldplay',
];

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final _controller = TextEditingController();
  bool _loading = false;
  List<Track>? _results;
  String _activeQuery = '';

  Future<void> _search(String q) async {
    if (q.trim().isEmpty) return;
    setState(() {
      _loading = true;
      _activeQuery = q;
    });
    try {
      final results = await MusicApi.searchTracks(q, limit: 30);
      setState(() => _results = results);
    } catch (_) {
      setState(() => _results = []);
    } finally {
      setState(() => _loading = false);
    }
  }

  void _submit(String q) {
    _controller.text = q;
    FocusScope.of(context).unfocus();
    _search(q);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBackground,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 20, 16, 0),
              child: Text(
                'Buscar',
                style: GoogleFonts.poppins(
                  fontSize: 28,
                  fontWeight: FontWeight.w900,
                  color: kForeground,
                ),
              ),
            ),
            // Search bar
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
              child: TextField(
                controller: _controller,
                style: const TextStyle(color: kForeground),
                onSubmitted: _submit,
                decoration: InputDecoration(
                  hintText: 'O que você quer ouvir?',
                  prefixIcon: const Icon(Icons.search, color: kMuted),
                  suffixIcon: _loading
                      ? const Padding(
                          padding: EdgeInsets.all(12),
                          child: SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: kPrimary,
                            ),
                          ),
                        )
                      : _controller.text.isNotEmpty
                          ? IconButton(
                              icon: const Icon(Icons.clear, color: kMuted),
                              onPressed: () {
                                _controller.clear();
                                setState(() {
                                  _results = null;
                                  _activeQuery = '';
                                });
                              },
                            )
                          : null,
                ),
                onChanged: (_) => setState(() {}),
              ),
            ),
            const SizedBox(height: 16),
            Expanded(
              child: _results == null
                  ? _SuggestionChips(onTap: _submit)
                  : _results!.isEmpty && !_loading
                      ? Center(
                          child: Text(
                            'Nenhum resultado para "$_activeQuery".',
                            style: const TextStyle(color: kMuted),
                          ),
                        )
                      : ListView.builder(
                          padding: const EdgeInsets.symmetric(horizontal: 8),
                          itemCount: _results!.length,
                          itemBuilder: (_, i) => TrackRow(
                            track: _results![i],
                            queue: _results!,
                            index: i,
                          ),
                        ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SuggestionChips extends StatelessWidget {
  final void Function(String) onTap;
  const _SuggestionChips({required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'SUGESTÕES',
            style: GoogleFonts.montserrat(
              fontSize: 10,
              fontWeight: FontWeight.w800,
              letterSpacing: 2,
              color: kMuted,
            ),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: _suggestions
                .map((s) => GestureDetector(
                      onTap: () => onTap(s),
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 10),
                        decoration: BoxDecoration(
                          border: Border.all(color: kBorder),
                          color: kSurface,
                          borderRadius: BorderRadius.circular(24),
                        ),
                        child: Text(
                          s,
                          style: const TextStyle(
                              fontSize: 13, color: kForeground),
                        ),
                      ),
                    ))
                .toList(),
          ),
        ],
      ),
    );
  }
}
