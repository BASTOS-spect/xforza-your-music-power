import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme/app_theme.dart';

class _Plan {
  final String id;
  final String name;
  final String price;
  final String period;
  final bool highlight;
  final String? badge;
  final List<String> features;

  const _Plan({
    required this.id,
    required this.name,
    required this.price,
    required this.period,
    this.highlight = false,
    this.badge,
    required this.features,
  });
}

const _plans = [
  _Plan(
    id: 'free',
    name: 'Livre',
    price: 'R\$ 0',
    period: 'Grátis',
    features: ['Reprodução limitada', 'Com anúncios', 'Qualidade padrão'],
  ),
  _Plan(
    id: 'premium',
    name: 'Premium',
    price: 'R\$ 14,90',
    period: '/mês',
    highlight: true,
    badge: 'Mais popular',
    features: [
      'Sem anúncios',
      'Favoritos ilimitados',
      'Qualidade de áudio superior',
      'Modo offline (em breve)',
    ],
  ),
  _Plan(
    id: 'ultra',
    name: 'Ultra',
    price: 'R\$ 24,90',
    period: '/mês',
    features: [
      'Todos os benefícios Premium',
      'Downloads offline',
      'Playlists exclusivas FORZA',
      'Qualidade Hi-Fi',
    ],
  ),
];

class PlansScreen extends StatelessWidget {
  const PlansScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBackground,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(16, 24, 16, 32),
          child: Column(
            children: [
              // Header
              Text(
                'Escolha a sua',
                style: GoogleFonts.poppins(
                  fontSize: 28,
                  fontWeight: FontWeight.w900,
                  color: kForeground,
                ),
              ),
              ShaderMask(
                shaderCallback: (bounds) =>
                    gradientPrimary.createShader(bounds),
                child: Text(
                  'experiência',
                  style: GoogleFonts.poppins(
                    fontSize: 28,
                    fontWeight: FontWeight.w900,
                    color: kForeground,
                  ),
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'Sem compromisso, cancele quando quiser.',
                style: TextStyle(color: kMuted, fontSize: 13),
              ),
              const SizedBox(height: 28),
              // Plan cards
              ..._plans.map((plan) => _PlanCard(plan: plan)),
            ],
          ),
        ),
      ),
    );
  }
}

class _PlanCard extends StatelessWidget {
  final _Plan plan;
  const _PlanCard({required this.plan});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: kSurface,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(
          color: plan.highlight ? kPrimary : kBorder,
          width: plan.highlight ? 1.5 : 1,
        ),
        boxShadow: plan.highlight
            ? [
                BoxShadow(
                  color: kPrimary.withAlpha(80),
                  blurRadius: 24,
                  spreadRadius: 2,
                ),
              ]
            : null,
      ),
      child: Stack(
        children: [
          Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              children: [
                Text(
                  plan.name,
                  style: GoogleFonts.poppins(
                    fontSize: 24,
                    fontWeight: FontWeight.w800,
                    color: kForeground,
                  ),
                ),
                const SizedBox(height: 12),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      plan.price,
                      style: GoogleFonts.poppins(
                        fontSize: 36,
                        fontWeight: FontWeight.w900,
                        color: kForeground,
                      ),
                    ),
                    const SizedBox(width: 4),
                    Padding(
                      padding: const EdgeInsets.only(bottom: 6),
                      child: Text(
                        plan.period,
                        style: const TextStyle(fontSize: 13, color: kMuted),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                ...plan.features.map(
                  (f) => Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: Row(
                      children: [
                        Container(
                          width: 20,
                          height: 20,
                          decoration: const BoxDecoration(
                            color: kPrimary,
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(Icons.check,
                              color: kForeground, size: 12),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            f,
                            style: const TextStyle(
                                fontSize: 13, color: kForeground),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                // CTA button
                GestureDetector(
                  onTap: () {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Em breve! Obrigado pelo interesse.'),
                        backgroundColor: kPrimary,
                      ),
                    );
                  },
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    decoration: BoxDecoration(
                      gradient:
                          plan.highlight || plan.id == 'ultra'
                              ? gradientPrimary
                              : null,
                      color: plan.id == 'free' ? kSurfaceElevated : null,
                      borderRadius: BorderRadius.circular(32),
                      boxShadow: plan.highlight
                          ? [
                              BoxShadow(
                                color: kPrimary.withAlpha(100),
                                blurRadius: 16,
                              ),
                            ]
                          : null,
                    ),
                    child: Text(
                      'Assinar',
                      textAlign: TextAlign.center,
                      style: GoogleFonts.montserrat(
                        fontSize: 13,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 1,
                        color: kForeground,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          // Badge
          if (plan.badge != null)
            Positioned(
              top: -1,
              left: 0,
              right: 0,
              child: Center(
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 5),
                  decoration: BoxDecoration(
                    gradient: gradientPrimary,
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: kPrimary.withAlpha(120),
                        blurRadius: 12,
                      ),
                    ],
                  ),
                  child: Text(
                    plan.badge!,
                    style: GoogleFonts.montserrat(
                      fontSize: 9,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 1.5,
                      color: kForeground,
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
