import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../models/track.dart';
import '../providers/player_provider.dart';
import '../services/music_api.dart';
import '../theme/app_theme.dart';
import '../widgets/music_widgets.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const _HeroBanner(),
          const SizedBox(height: 8),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _CategorySection(
                  title: 'Em Alta',
                  icon: Icons.trending_up,
                  category: 'trending',
                ),
                const SizedBox(height: 28),
                _ObjectivesSection(),
                const SizedBox(height: 28),
                _CategorySection(
                  title: 'Novidades',
                  icon: Icons.auto_awesome,
                  category: 'novidades',
                ),
                const SizedBox(height: 28),
                _GenresSection(),
                const SizedBox(height: 28),
                _FavoritesSection(),
                const SizedBox(height: 32),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ── Hero Banner ──────────────────────────────────────────────────────────────

class _HeroBanner extends StatelessWidget {
  const _HeroBanner();

  @override
  Widget build(BuildContext context) {
    final player = context.watch<PlayerProvider>();

    return FutureBuilder<List<Track>>(
      future: MusicApi.getCategory('trending', limit: 6),
      builder: (context, snap) {
        final tracks = snap.data ?? [];

        return Container(
          height: 280,
          width: double.infinity,
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Color(0x99E50914),
                Color(0x66B30000),
                Color(0xFF0A0A0A),
              ],
            ),
          ),
          child: Stack(
            children: [
              // Radial glow
              Positioned.fill(
                child: Container(
                  decoration: const BoxDecoration(
                    gradient: RadialGradient(
                      center: Alignment.topCenter,
                      radius: 1.2,
                      colors: [Color(0x55E50914), Colors.transparent],
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 40, 20, 24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      padding:
                          const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                      decoration: BoxDecoration(
                        border: Border.all(color: kPrimary.withAlpha(100)),
                        color: kPrimary.withAlpha(26),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(
                        'ECOSSISTEMA FORZA',
                        style: GoogleFonts.montserrat(
                          fontSize: 10,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 2,
                          color: kPrimary,
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      'Sua trilha\nsonora começa\naqui.',
                      style: GoogleFonts.poppins(
                        fontSize: 30,
                        fontWeight: FontWeight.w900,
                        height: 1.05,
                        color: kForeground,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'A energia da música em um só lugar.',
                      style: const TextStyle(fontSize: 13, color: kMuted),
                    ),
                    const Spacer(),
                    GestureDetector(
                      onTap: tracks.isNotEmpty
                          ? () => player.play(tracks.first, newQueue: tracks)
                          : null,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 24, vertical: 13),
                        decoration: BoxDecoration(
                          gradient: gradientPrimary,
                          borderRadius: BorderRadius.circular(32),
                          boxShadow: [
                            BoxShadow(
                              color: kPrimary.withAlpha(140),
                              blurRadius: 20,
                              spreadRadius: 2,
                            ),
                          ],
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(Icons.play_arrow,
                                color: kForeground, size: 18),
                            const SizedBox(width: 8),
                            Text(
                              'OUVIR AGORA',
                              style: GoogleFonts.montserrat(
                                fontSize: 12,
                                fontWeight: FontWeight.w800,
                                letterSpacing: 1.5,
                                color: kForeground,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

// ── Section heading ──────────────────────────────────────────────────────────

class _SectionHeading extends StatelessWidget {
  final String title;
  final IconData? icon;

  const _SectionHeading({required this.title, this.icon});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        if (icon != null) ...[
          Icon(icon, color: kPrimary, size: 20),
          const SizedBox(width: 8),
        ],
        Text(
          title,
          style: GoogleFonts.poppins(
            fontSize: 20,
            fontWeight: FontWeight.w800,
            color: kForeground,
          ),
        ),
      ],
    );
  }
}

// ── Category Section ─────────────────────────────────────────────────────────

class _CategorySection extends StatefulWidget {
  final String title;
  final IconData? icon;
  final String category;
  final int limit;

  const _CategorySection({
    required this.title,
    this.icon,
    required this.category,
    this.limit = 6,
  });

  @override
  State<_CategorySection> createState() => _CategorySectionState();
}

class _CategorySectionState extends State<_CategorySection> {
  late Future<List<Track>> _future;

  @override
  void initState() {
    super.initState();
    _future = MusicApi.getCategory(widget.category, limit: widget.limit);
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _SectionHeading(title: widget.title, icon: widget.icon),
        const SizedBox(height: 14),
        FutureBuilder<List<Track>>(
          future: _future,
          builder: (context, snap) {
            if (snap.connectionState == ConnectionState.waiting) {
              return GridView.builder(
                physics: const NeverScrollableScrollPhysics(),
                shrinkWrap: true,
                itemCount: widget.limit,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3,
                  crossAxisSpacing: 12,
                  mainAxisSpacing: 12,
                  childAspectRatio: 0.72,
                ),
                itemBuilder: (_, __) => const CardSkeleton(),
              );
            }
            final tracks = snap.data ?? [];
            return GridView.builder(
              physics: const NeverScrollableScrollPhysics(),
              shrinkWrap: true,
              itemCount: tracks.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                childAspectRatio: 0.72,
              ),
              itemBuilder: (_, i) =>
                  TrackCard(track: tracks[i], queue: tracks),
            );
          },
        ),
      ],
    );
  }
}

// ── Objectives Section ───────────────────────────────────────────────────────

const _objectives = [
  {'key': 'treino', 'label': 'Treino', 'desc': 'Academia · Corrida', 'icon': Icons.fitness_center},
  {'key': 'foco', 'label': 'Foco', 'desc': 'Lo-Fi · Study', 'icon': Icons.psychology},
  {'key': 'relaxar', 'label': 'Relaxar', 'desc': 'Chill · Acoustic', 'icon': Icons.waves},
  {'key': 'viagem', 'label': 'Viagem', 'desc': 'Road Trip · Summer', 'icon': Icons.flight},
  {'key': 'motivacao', 'label': 'Motivação', 'desc': 'Hits · Hip-Hop', 'icon': Icons.local_fire_department},
];

class _ObjectivesSection extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const _SectionHeading(title: 'Por Objetivo', icon: Icons.local_fire_department),
        const SizedBox(height: 14),
        SizedBox(
          height: 130,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: _objectives.length,
            separatorBuilder: (_, __) => const SizedBox(width: 10),
            itemBuilder: (context, i) {
              final obj = _objectives[i];
              return _ObjectiveCard(obj: obj);
            },
          ),
        ),
      ],
    );
  }
}

class _ObjectiveCard extends StatefulWidget {
  final Map<String, Object> obj;
  const _ObjectiveCard({required this.obj});

  @override
  State<_ObjectiveCard> createState() => _ObjectiveCardState();
}

class _ObjectiveCardState extends State<_ObjectiveCard> {
  List<Track>? _tracks;

  @override
  void initState() {
    super.initState();
    MusicApi.getCategory(widget.obj['key'] as String, limit: 4).then((t) {
      if (mounted) setState(() => _tracks = t);
    });
  }

  @override
  Widget build(BuildContext context) {
    final player = context.watch<PlayerProvider>();
    final icon = widget.obj['icon'] as IconData;

    return GestureDetector(
      onTap: _tracks != null && _tracks!.isNotEmpty
          ? () => player.play(_tracks!.first, newQueue: _tracks!)
          : null,
      child: Container(
        width: 150,
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0x33E50914), Color(0x110A0A0A)],
          ),
          border: Border.all(color: kBorder),
          borderRadius: BorderRadius.circular(16),
        ),
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: kPrimary, size: 26),
            const Spacer(),
            Text(
              widget.obj['label'] as String,
              style: GoogleFonts.poppins(
                fontSize: 16,
                fontWeight: FontWeight.w800,
                color: kForeground,
              ),
            ),
            Text(
              widget.obj['desc'] as String,
              style: const TextStyle(fontSize: 10, color: kMuted),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Genres Section ───────────────────────────────────────────────────────────

const _genres = [
  {'key': 'pop', 'name': 'Pop'},
  {'key': 'rock', 'name': 'Rock'},
  {'key': 'hiphop', 'name': 'Hip-Hop'},
  {'key': 'eletronica', 'name': 'Eletrônica'},
  {'key': 'lofi', 'name': 'Lo-Fi'},
];

const _genreColors = [
  [Color(0x66EC4899), Color(0x66E50914)],
  [Color(0x66EA580C), Color(0x66E50914)],
  [Color(0x66F59E0B), Color(0x66E50914)],
  [Color(0x66A855F7), Color(0x66E50914)],
  [Color(0x667C3AED), Color(0x66E50914)],
];

class _GenresSection extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const _SectionHeading(title: 'Gêneros'),
        const SizedBox(height: 14),
        GridView.builder(
          physics: const NeverScrollableScrollPhysics(),
          shrinkWrap: true,
          itemCount: _genres.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
            childAspectRatio: 2.5,
          ),
          itemBuilder: (_, i) {
            final g = _genres[i];
            final colors = _genreColors[i % _genreColors.length];
            return Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: colors,
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(12),
              ),
              alignment: Alignment.centerLeft,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Text(
                g['name']!,
                style: GoogleFonts.poppins(
                  fontSize: 18,
                  fontWeight: FontWeight.w900,
                  color: kForeground,
                ),
              ),
            );
          },
        ),
      ],
    );
  }
}

// ── Favorites Section ────────────────────────────────────────────────────────

class _FavoritesSection extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final player = context.watch<PlayerProvider>();
    if (player.favoriteTracks.isEmpty) return const SizedBox.shrink();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const _SectionHeading(title: 'Favoritos', icon: Icons.favorite),
        const SizedBox(height: 14),
        GridView.builder(
          physics: const NeverScrollableScrollPhysics(),
          shrinkWrap: true,
          itemCount: player.favoriteTracks.take(6).length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 3,
            crossAxisSpacing: 12,
            mainAxisSpacing: 12,
            childAspectRatio: 0.72,
          ),
          itemBuilder: (_, i) => TrackCard(
            track: player.favoriteTracks[i],
            queue: player.favoriteTracks,
          ),
        ),
      ],
    );
  }
}
