import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../providers/player_provider.dart';
import '../theme/app_theme.dart';
import '../widgets/music_widgets.dart';

class LibraryScreen extends StatelessWidget {
  const LibraryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final player = context.watch<PlayerProvider>();
    final tracks = player.favoriteTracks;

    return Scaffold(
      backgroundColor: kBackground,
      body: SafeArea(
        child: CustomScrollView(
          slivers: [
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 20, 16, 24),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    // Playlist cover
                    Container(
                      width: 110,
                      height: 110,
                      decoration: BoxDecoration(
                        gradient: gradientPrimary,
                        borderRadius: BorderRadius.circular(16),
                        boxShadow: [
                          BoxShadow(
                            color: kPrimary.withAlpha(120),
                            blurRadius: 24,
                            spreadRadius: 4,
                          ),
                        ],
                      ),
                      child: const Icon(Icons.favorite,
                          color: kForeground, size: 50),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'PLAYLIST',
                            style: GoogleFonts.montserrat(
                              fontSize: 10,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 2,
                              color: kMuted,
                            ),
                          ),
                          Text(
                            'Favoritos',
                            style: GoogleFonts.poppins(
                              fontSize: 28,
                              fontWeight: FontWeight.w900,
                              color: kForeground,
                            ),
                          ),
                          Text(
                            '${tracks.length} ${tracks.length == 1 ? "música" : "músicas"} salvas',
                            style:
                                const TextStyle(fontSize: 12, color: kMuted),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),

            // Empty state
            if (tracks.isEmpty)
              SliverFillRemaining(
                child: Padding(
                  padding: const EdgeInsets.all(32),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.library_music_outlined,
                          color: kMuted, size: 56),
                      const SizedBox(height: 16),
                      Text(
                        'Sua biblioteca está vazia',
                        style: GoogleFonts.poppins(
                          fontSize: 20,
                          fontWeight: FontWeight.w700,
                          color: kForeground,
                        ),
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        'Toque o coração em qualquer música para salvá-la aqui.',
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 13, color: kMuted),
                      ),
                      const SizedBox(height: 24),
                      GestureDetector(
                        onTap: () => context.go('/buscar'),
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 24, vertical: 13),
                          decoration: BoxDecoration(
                            gradient: gradientPrimary,
                            borderRadius: BorderRadius.circular(32),
                            boxShadow: [
                              BoxShadow(
                                color: kPrimary.withAlpha(120),
                                blurRadius: 20,
                              ),
                            ],
                          ),
                          child: Text(
                            'DESCOBRIR MÚSICAS',
                            style: GoogleFonts.montserrat(
                              fontSize: 11,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 1.5,
                              color: kForeground,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              )
            else ...[
              // Play all button
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: GestureDetector(
                      onTap: () =>
                          player.play(tracks.first, newQueue: tracks),
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 22, vertical: 12),
                        decoration: BoxDecoration(
                          gradient: gradientPrimary,
                          borderRadius: BorderRadius.circular(32),
                          boxShadow: [
                            BoxShadow(
                              color: kPrimary.withAlpha(120),
                              blurRadius: 18,
                            ),
                          ],
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(Icons.play_arrow,
                                color: kForeground, size: 18),
                            const SizedBox(width: 8),
                            Text(
                              'TOCAR TUDO',
                              style: GoogleFonts.montserrat(
                                fontSize: 11,
                                fontWeight: FontWeight.w800,
                                letterSpacing: 1.5,
                                color: kForeground,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              // Track list
              SliverList.builder(
                itemCount: tracks.length,
                itemBuilder: (_, i) =>
                    TrackRow(track: tracks[i], queue: tracks, index: i),
              ),
              const SliverToBoxAdapter(child: SizedBox(height: 24)),
            ],
          ],
        ),
      ),
    );
  }
}
