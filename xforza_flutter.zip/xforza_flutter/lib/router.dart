import 'package:go_router/go_router.dart';
import '../screens/home_screen.dart';
import '../screens/search_screen.dart';
import '../screens/library_screen.dart';
import '../screens/plans_screen.dart';
import '../widgets/app_shell.dart';

final router = GoRouter(
  initialLocation: '/',
  routes: [
    ShellRoute(
      builder: (context, state, child) {
        int index = 0;
        final location = state.uri.path;
        if (location.startsWith('/buscar')) index = 1;
        else if (location.startsWith('/biblioteca')) index = 2;
        else if (location.startsWith('/planos')) index = 3;
        return AppShell(currentIndex: index, child: child);
      },
      routes: [
        GoRoute(path: '/', builder: (_, __) => const HomeScreen()),
        GoRoute(path: '/buscar', builder: (_, __) => const SearchScreen()),
        GoRoute(path: '/biblioteca', builder: (_, __) => const LibraryScreen()),
        GoRoute(path: '/planos', builder: (_, __) => const PlansScreen()),
      ],
    ),
  ],
);
